# Gerador de Senhas — Trabalho HTML, CSS e JavaScript

Projeto de página responsiva para gerar senhas aleatórias com mínimo de 8 e máximo de 64 caracteres.

## Como executar
1. Abra a pasta no Visual Studio Code.
2. Abra `index.html` no navegador (ou use a extensão Live Server).
3. Escolha o tamanho e as categorias de caracteres.
4. Clique em **Gerar senha forte** e depois em **Copiar**.

## Arquivos
- `index.html`: estrutura da página.
- `style.css`: aparência e responsividade.
- `script.js`: geração, validações e cópia.

## Publicar no GitHub Pages
1. Crie um repositório público no GitHub.
2. Envie os três arquivos (`index.html`, `style.css`, `script.js`) para a raiz do repositório.
3. Acesse **Settings > Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**, branch **main**, pasta **/(root)**, e salve.
5. Aguarde a publicação e copie o link indicado pelo GitHub Pages para entregar na atividade.

## Observações
- A senha é gerada no próprio navegador, sem envio a servidores.
- O JavaScript usa `crypto.getRandomValues()` para obter aleatoriedade adequada para senhas.
- O indicador de força é uma estimativa visual simplificada, não uma auditoria de segurança.
