// Conjuntos de caracteres usados na geração.
const conjuntos = {
  maiusculas: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  minusculas: 'abcdefghijklmnopqrstuvwxyz',
  numeros: '0123456789',
  simbolos: '!@#$%^&*()_+-=[]{}?'
};
const senhaInput = document.getElementById('senha');
const tamanhoInput = document.getElementById('tamanho');
const mensagem = document.getElementById('mensagem');
const tipos = Object.keys(conjuntos);
let senhaVisivel = true;

// Gera um índice aleatório usando a API criptográfica do navegador.
// A rejeição evita o pequeno viés de usar módulo diretamente.
function indiceSeguro(maximo) {
  const limite = Math.floor(4294967296 / maximo) * maximo;
  const valores = new Uint32Array(1);
  do { crypto.getRandomValues(valores); } while (valores[0] >= limite);
  return valores[0] % maximo;
}

function mostrarMensagem(texto, erro = false) {
  mensagem.textContent = texto;
  mensagem.classList.toggle('error', erro);
}

function avaliarForca(tamanho, quantidadeTipos) {
  const barra = document.getElementById('barra');
  const forca = document.getElementById('forca');
  const pontuacao = (tamanho >= 12 ? 1 : 0) + (tamanho >= 16 ? 1 : 0) + (quantidadeTipos >= 2 ? 1 : 0) + (quantidadeTipos >= 3 ? 1 : 0);
  const niveis = [ ['Básica', '25%', '#f87171'], ['Moderada', '45%', '#fbbf24'], ['Boa', '65%', '#facc15'], ['Forte', '85%', '#80f0c1'], ['Muito forte', '100%', '#4ade80'] ];
  const [nome, largura, cor] = niveis[pontuacao];
  forca.textContent = nome;
  forca.style.color = cor;
  barra.style.width = largura;
  barra.style.background = cor;
}

function gerarSenha() {
  const tamanho = Number(tamanhoInput.value);
  const selecionados = tipos.filter(tipo => document.getElementById(tipo).checked);
  if (!selecionados.length) { mostrarMensagem('Selecione pelo menos um tipo de caractere.', true); return; }
  if (!Number.isInteger(tamanho) || tamanho < 8 || tamanho > 64) { mostrarMensagem('Escolha um tamanho entre 8 e 64 caracteres.', true); return; }
  let caracteres = '';
  const resultado = [];
  for (const tipo of selecionados) {
    const grupo = conjuntos[tipo];
    caracteres += grupo;
    // Garante pelo menos um caractere de cada categoria selecionada.
    resultado.push(grupo.charAt(indiceSeguro(grupo.length)));
  }
  while (resultado.length < tamanho) resultado.push(caracteres.charAt(indiceSeguro(caracteres.length)));
  // Embaralhamento Fisher-Yates para misturar os caracteres obrigatórios.
  for (let i = resultado.length - 1; i > 0; i--) {
    const j = indiceSeguro(i + 1);
    [resultado[i], resultado[j]] = [resultado[j], resultado[i]];
  }
  senhaInput.value = resultado.join('');
  senhaInput.type = senhaVisivel ? 'text' : 'password';
  avaliarForca(tamanho, selecionados.length);
  mostrarMensagem('Senha gerada com sucesso!');
}

async function copiarSenha() {
  if (!senhaInput.value) { mostrarMensagem('Gere uma senha antes de copiar.', true); return; }
  try {
    await navigator.clipboard.writeText(senhaInput.value);
    mostrarMensagem('Senha copiada para a área de transferência!');
  } catch {
    // Em arquivos locais, alguns navegadores restringem a API Clipboard.
    senhaInput.focus(); senhaInput.select();
    mostrarMensagem('Selecione a senha e pressione Ctrl+C para copiar.', true);
  }
}

document.getElementById('gerar').addEventListener('click', gerarSenha);
document.getElementById('copiar').addEventListener('click', copiarSenha);
document.getElementById('visibilidade').addEventListener('click', () => {
  senhaVisivel = !senhaVisivel;
  senhaInput.type = senhaVisivel ? 'text' : 'password';
  document.getElementById('visibilidade').setAttribute('aria-label', senhaVisivel ? 'Ocultar senha' : 'Mostrar senha');
});
tamanhoInput.addEventListener('input', () => { document.getElementById('valor-tamanho').textContent = `${tamanhoInput.value} caracteres`; });
